package com.example.waterbuddy.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.waterbuddy.data.dao.UserDao
import com.example.waterbuddy.data.dao.ReminderDao
import com.example.waterbuddy.data.model.User
import com.example.waterbuddy.data.model.Reminder

@Database(
    entities = [User::class, Reminder::class],
    version = 1,
    exportSchema = false
)
abstract class WaterBuddyDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun reminderDao(): ReminderDao

    companion object {
        @Volatile
        private var INSTANCE: WaterBuddyDatabase? = null

        fun getDatabase(context: Context): WaterBuddyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WaterBuddyDatabase::class.java,
                    "waterbuddy_db"
                ).build()

                INSTANCE = instance
                instance
            }
        }
    }
}
