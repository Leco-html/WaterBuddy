package com.example.waterbuddy.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.waterbuddy.R
import com.example.waterbuddy.data.database.WaterBuddyDatabase
import com.example.waterbuddy.data.model.User
import com.example.waterbuddy.ui.home.HomeActivity
import com.example.waterbuddy.ui.viewmodel.UserViewModel
import com.example.waterbuddy.ui.viewmodel.ViewModelFactory

class LoginActivity : AppCompatActivity() {

    private lateinit var viewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Cria a factory passando apenas a database
        val database = WaterBuddyDatabase.getDatabase(this)
        val factory = ViewModelFactory(database)

        // Instancia o ViewModel de forma correta
        viewModel = ViewModelProvider(this, factory)[UserViewModel::class.java]

        val etName = findViewById<EditText>(R.id.etName)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etAge = findViewById<EditText>(R.id.etAge)
        val etHeight = findViewById<EditText>(R.id.etHeight)
        val etWeight = findViewById<EditText>(R.id.etWeight)
        val btnSave = findViewById<Button>(R.id.btnSave)

        btnSave.setOnClickListener {
            val user = User(
                id = 1, // ou 0 se preferires auto-generate
                name = etName.text.toString().trim(),
                email = etEmail.text.toString().trim(),
                age = etAge.text.toString().toIntOrNull() ?: 0,
                height = etHeight.text.toString().toIntOrNull() ?: 0,
                weight = etWeight.text.toString().toFloatOrNull() ?: 0f
            )

            viewModel.insert(user)

            // Vai direto para a Home
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }
}