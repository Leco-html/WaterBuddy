package com.example.waterbuddy.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = false)
    val id: Int = 1,

    val name: String,
    val email: String,
    val age: Int,
    val height: Int,
    val weight: Float
)