package com.example.waterbuddy.ui.home

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.waterbuddy.databinding.ActivityHomeBinding
import com.example.waterbuddy.ui.login.LoginActivity
import com.example.waterbuddy.ui.reminders.AddReminderActivity
import com.example.waterbuddy.ui.reminders.ReminderListActivity

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Botão: Adicionar lembrete
        binding.btnAddReminder.setOnClickListener {
            startActivity(Intent(this, AddReminderActivity::class.java))
        }

        // Botão: Ver lembretes
        binding.btnViewReminders.setOnClickListener {
            startActivity(Intent(this, ReminderListActivity::class.java))
        }

        // Botão: Logout
        binding.btnLogout.setOnClickListener {
            // Volta pro login
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }
}