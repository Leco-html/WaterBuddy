package com.example.waterbuddy.ui.reminders

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.waterbuddy.R
import com.example.waterbuddy.data.model.Reminder

class ReminderAdapter(
    private val onTaken: (Reminder, Boolean) -> Unit
) : ListAdapter<Reminder, ReminderAdapter.VH>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Reminder>() {
            override fun areItemsTheSame(oldItem: Reminder, newItem: Reminder): Boolean =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: Reminder, newItem: Reminder): Boolean =
                oldItem == newItem
        }
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvRemName)
        val tvTime: TextView = view.findViewById(R.id.tvRemTime)
        val tvAmount: TextView = view.findViewById(R.id.tvRemAmount)
        val btnTaken: Button = view.findViewById(R.id.btnTaken)
        val btnNotTaken: Button = view.findViewById(R.id.btnNotTaken)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_reminder, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)

        holder.tvName.text = item.title
        holder.tvTime.text = item.time
        holder.tvAmount.text = "${item.amountMl}ml"

        holder.btnTaken.setOnClickListener { onTaken(item, true) }
        holder.btnNotTaken.setOnClickListener { onTaken(item, false) }

        holder.btnTaken.isEnabled = !item.done
    }
}