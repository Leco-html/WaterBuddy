package com.example.waterbuddy.data.repository

import androidx.lifecycle.LiveData
import com.example.waterbuddy.data.dao.UserDao
import com.example.waterbuddy.data.model.User

class UserRepository(private val userDao: UserDao) {

    // chama o met insert() do seu UserDao
    suspend fun insert(user: User) {
        userDao.insert(user)
    }

    // expõe LiveData (igual ao DAO)
    fun getUser(): LiveData<User?> {
        return userDao.getUser()
    }

    suspend fun update(user: User) {
        userDao.update(user)
    }

    suspend fun delete(user: User) {
        userDao.delete(user)
    }
}
