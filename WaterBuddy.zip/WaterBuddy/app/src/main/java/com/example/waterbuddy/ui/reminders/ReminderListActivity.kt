package com.example.waterbuddy.ui.reminders

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.waterbuddy.data.database.WaterBuddyDatabase
import com.example.waterbuddy.data.repository.ReminderRepository
import com.example.waterbuddy.databinding.ActivityReminderListBinding
import com.example.waterbuddy.ui.viewmodel.ReminderViewModel
import com.example.waterbuddy.ui.viewmodel.ReminderViewModelFactory

class ReminderListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReminderListBinding

    private val viewModel: ReminderViewModel by viewModels {
        val dao = WaterBuddyDatabase.getDatabase(this).reminderDao()
        val repo = ReminderRepository(dao)
        ReminderViewModelFactory(repo)
    }

    private lateinit var adapter: ReminderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReminderListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ReminderAdapter { reminder, taken ->
            val updated = reminder.copy(done = taken)
            viewModel.update(updated)
        }

        binding.rvReminders.layoutManager = LinearLayoutManager(this)
        binding.rvReminders.adapter = adapter

        viewModel.getAll().observe(this) { reminders ->
            adapter.submitList(reminders)
        }

        binding.fabAddReminder.setOnClickListener {
            startActivity(Intent(this, AddReminderActivity::class.java))
        }
    }
}