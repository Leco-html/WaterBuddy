package com.example.waterbuddy.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.waterbuddy.data.model.User
import com.example.waterbuddy.data.repository.UserRepository
import kotlinx.coroutines.launch

class UserViewModel(private val userRepository: UserRepository) : ViewModel() {

    fun insert(user: User) {
        viewModelScope.launch {
            userRepository.insert(user)
        }
    }
}