// ViewModelFactory.kt
package com.example.waterbuddy.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.waterbuddy.data.database.WaterBuddyDatabase
import com.example.waterbuddy.data.repository.ReminderRepository
import com.example.waterbuddy.data.repository.UserRepository
import com.example.waterbuddy.ui.viewmodel.ReminderViewModel
import com.example.waterbuddy.ui.viewmodel.UserViewModel

class ViewModelFactory(
    private val database: WaterBuddyDatabase
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ReminderViewModel::class.java) -> {
                val reminderDao = database.reminderDao()
                val reminderRepository = ReminderRepository(reminderDao)
                ReminderViewModel(reminderRepository) as T
            }

            modelClass.isAssignableFrom(UserViewModel::class.java) -> {
                val userDao = database.userDao()
                val userRepository = UserRepository(userDao)
                UserViewModel(userRepository) as T
            }

            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}