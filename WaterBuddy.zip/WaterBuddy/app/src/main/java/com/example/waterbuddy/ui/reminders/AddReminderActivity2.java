package com.example.waterbuddy.ui.reminders;

public class AddReminderActivity2 {
}
