package com.example.waterbuddy.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.waterbuddy.data.model.Reminder
import com.example.waterbuddy.data.repository.ReminderRepository
import kotlinx.coroutines.launch

class ReminderViewModel(private val repository: ReminderRepository) : ViewModel() {

    fun insert(reminder: Reminder) {
        viewModelScope.launch {
            repository.insert(reminder)
        }
    }

    fun update(reminder: Reminder) {
        viewModelScope.launch {
            repository.update(reminder)
        }
    }

    fun delete(reminder: Reminder) {
        viewModelScope.launch {
            repository.delete(reminder)
        }
    }

    fun getAll(): LiveData<List<Reminder>> {
        return repository.getAll()
    }

    fun getById(id: Int): LiveData<Reminder?> {
        return repository.getById(id)
    }
}