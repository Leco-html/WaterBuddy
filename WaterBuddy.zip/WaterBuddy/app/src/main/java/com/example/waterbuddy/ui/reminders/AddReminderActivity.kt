package com.example.waterbuddy.ui.reminders

import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.waterbuddy.R
import com.example.waterbuddy.data.database.WaterBuddyDatabase
import com.example.waterbuddy.data.model.Reminder
import com.example.waterbuddy.data.repository.ReminderRepository
import kotlinx.coroutines.launch
import java.util.*

class AddReminderActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etAmount: EditText
    private lateinit var tvSelectedTime: TextView
    private lateinit var btnSelectTime: Button
    private lateinit var btnSave: Button

    private var selectedHour = -1
    private var selectedMinute = -1

    private lateinit var repository: ReminderRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_reminder)

        // Inicializar componentes da UI
        etName = findViewById(R.id.etReminderName)
        etAmount = findViewById(R.id.etReminderAmount)
        tvSelectedTime = findViewById(R.id.tvSelectedTime)
        btnSelectTime = findViewById(R.id.btnSelectTime)
        btnSave = findViewById(R.id.btnSaveReminder)

        // Inicializar o repositório
        val dao = WaterBuddyDatabase.getDatabase(this).reminderDao()
        repository = ReminderRepository(dao)

        // Abrir TimePicker
        btnSelectTime.setOnClickListener { openTimePicker() }

        // Salvar lembrete
        btnSave.setOnClickListener { saveReminder() }
    }

    private fun openTimePicker() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val picker = TimePickerDialog(
            this,
            { _, selectedH, selectedM ->
                selectedHour = selectedH
                selectedMinute = selectedM
                tvSelectedTime.text = String.format("%02d:%02d", selectedHour, selectedMinute)
            },
            hour,
            minute,
            true
        )

        picker.show()
    }

    private fun saveReminder() {
        val name = etName.text.toString().trim()
        val amount = etAmount.text.toString().trim()

        if (name.isEmpty() || amount.isEmpty() || selectedHour == -1) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            return
        }

        val reminder = Reminder(
            id = 0, // ID autogerado pelo Room
            title = name,
            name = name,
            time = String.format("%02d:%02d", selectedHour, selectedMinute),
            amountMl = amount.toInt(),
            done = false
        )

        lifecycleScope.launch {
            repository.insert(reminder)
            Toast.makeText(this@AddReminderActivity, "Lembrete criado!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}