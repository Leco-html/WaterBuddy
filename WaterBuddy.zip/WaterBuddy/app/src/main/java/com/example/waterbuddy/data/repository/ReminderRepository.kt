package com.example.waterbuddy.data.repository

import androidx.lifecycle.LiveData
import com.example.waterbuddy.data.dao.ReminderDao
import com.example.waterbuddy.data.model.Reminder

class ReminderRepository(private val reminderDao: ReminderDao) {

    suspend fun insert(reminder: Reminder): Long {
        return reminderDao.insert(reminder)
    }

    fun getAll(): LiveData<List<Reminder>> {
        return reminderDao.getAll()
    }

    fun getById(id: Int): LiveData<Reminder?> {
        return reminderDao.getById(id)
    }

    suspend fun update(reminder: Reminder) {
        reminderDao.update(reminder)
    }

    suspend fun delete(reminder: Reminder) {
        reminderDao.delete(reminder)
    }
}