package com.example.waterbuddy.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val title: String,       // nome do lembrete
    val time: String,        // formato "HH:mm"
    val amountMl: Int,       // quantidade de água do lembrete
    val done: Boolean = false,  // se o usuário tomou água ou não
    val name: String
)