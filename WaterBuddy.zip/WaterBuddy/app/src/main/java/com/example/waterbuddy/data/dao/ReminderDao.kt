package com.example.waterbuddy.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.waterbuddy.data.model.Reminder

@Dao
interface ReminderDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reminder: Reminder): Long

    @Update
    suspend fun update(reminder: Reminder)

    @Delete
    suspend fun delete(reminder: Reminder)

    @Query("SELECT * FROM reminders ORDER BY time")
    fun getAll(): LiveData<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    fun getById(id: Int): LiveData<Reminder?>
}
